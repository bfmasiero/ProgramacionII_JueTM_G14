package interfaces;

public interface IPersona {
    String getNombre();
    String getDni();
}
